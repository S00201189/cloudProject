const AWS = require('aws-sdk');
const redis = require('redis');
const bluebird = require('bluebird');

// Promisify Redis client
bluebird.promisifyAll(redis);

const docClient = new AWS.DynamoDB.DocumentClient();
const params = {
  TableName: 'products',
  
};

// Replace with your Redis cluster's endpoint and port
const redisEndpoint = process.env.REDIS_ENDPOINT;
const redisPort = process.env.REDIS_PORT;

// Create a Redis client and connect to the Redis cluster
const redisClient = redis.createClient(redisPort, redisEndpoint);

exports.handler = async (event, context) => {
  try {
    const cacheKey = 'productsCache';

    // Check if data is available in Redis cache
    const cachedData = await redisClient.getAsync(cacheKey);

    if (cachedData) {
      // Data found in cache, return it
      return { body: cachedData };
    } else {
      // Data not found in cache, fetch it from DynamoDB
      const data = await docClient.scan(params).promise();

      // Store the data in Redis cache with a 1-hour TTL
      await redisClient.setAsync(cacheKey, JSON.stringify(data.Items), 'EX', 3600);

      return { body: JSON.stringify(data.Items) };
    }
  } catch (err) {
    return { error: err };
  }
};
