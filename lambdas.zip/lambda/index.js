const AWS = require("aws-sdk");
const docClient = new AWS.DynamoDB.DocumentClient();
const { v4: uuidv4 } = require('uuid');

exports.handler = async (event, context) => {
  const requestBody = JSON.parse(event.body);

  const params = {
    TableName: "orders",
    Item: {
      id: uuidv4(),
      firstName: requestBody.firstName,
      lastName: requestBody.lastName,
      address: requestBody.address,
      eircode: requestBody.eircode,
      state: requestBody.state,
      nameOnCard: requestBody.nameOnCard,
      creditCardNumber: requestBody.creditCardNumber,
      expiryDate: requestBody.expiryDate,
      cvv: requestBody.cvv
    },
  };

  try {
    await docClient.put(params).promise();
    return {
      statusCode: 200,
      body: JSON.stringify({ message: "Order saved successfully!" }),
    };
  } catch (error) {
    console.error("Error saving order:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "Error saving order" }),
    };
  }
};
